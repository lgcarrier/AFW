CONAL

Avant de faire des modifications (�crasement du fichier), j'aimerais �tre au courant svp.
Il y a du code sp�cifiquement AFW pour g�rer les requests ajax.