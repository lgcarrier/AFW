# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DemoOnRails::Application.config.secret_token = '16826aada1de555db29842bc1c734137271b9b6ca23826a73862ba0e33a109a8065980fdd94221deaa4e1d10f0eb01d03b0f152674757d3dd377cb22b3bca88e'
